module Main (main) where

import Bench.Catch.Eff qualified as CatchEff
import Bench.Catch.Effectful qualified as CatchEffectful
import Bench.Catch.EffectiveFullyStaged qualified as CatchEffectiveFullyStaged
import Bench.Catch.EffectiveLightlyStaged qualified as CatchEffectiveLightlyStaged
import Bench.Catch.FreerSimple qualified as CatchFreer
import Bench.Catch.FusedEffects qualified as CatchFused
import Bench.Catch.Heftia qualified as CatchHeftia
import Bench.Catch.Mpeff.Safe qualified as CatchMpeffSafe
import Bench.Catch.Mpeff.Unsafe qualified as CatchMpeff
import Bench.Catch.Mtl qualified as CatchMtl
import Bench.Catch.Polysemy qualified as CatchPolysemy
import Bench.Catch.Effective qualified as CatchEffective
import Bench.Catch.EffectiveNaive qualified as CatchEffectiveNaive
import Bench.Catch.Handrolled qualified as CatchHandrolled
import Bench.Countdown.Handrolled qualified as CountdownHandrolled
import Bench.Countdown.Eff qualified as CountdownEff
import Bench.Countdown.Effective qualified as CountdownEffective
import Bench.Countdown.EffectiveFullyStaged qualified as CountdownEffectiveFullyStaged
import Bench.Countdown.EffectiveLightlyStaged qualified as CountdownEffectiveLightlyStaged
import Bench.Countdown.EffectiveNaive qualified as CountdownEffectiveNaive
import Bench.Countdown.Effectful qualified as CountdownEffectful
import Bench.Countdown.FreerSimple qualified as CountdownFreer
import Bench.Countdown.FusedEffects qualified as CountdownFused
import Bench.Countdown.Heftia qualified as CountdownHeftia
import Bench.Countdown.Mpeff.Safe qualified as CountdownMpeffSafe
import Bench.Countdown.Mpeff.Unsafe qualified as CountdownMpeff
import Bench.Countdown.Mtl qualified as CountdownMtl
import Bench.Countdown.Polysemy qualified as CountdownPolysemy
import Bench.Local.Effectful qualified as LocalEffectful
import Bench.Local.Eff qualified as LocalEff
import Bench.Local.Effective qualified as LocalEffective
import Bench.Local.EffectiveFullyStaged qualified as LocalEffectiveFullyStaged
import Bench.Local.EffectiveLightlyStaged qualified as LocalEffectiveLightlyStaged
import Bench.Local.EffectiveNaive qualified as LocalEffectiveNaive
import Bench.Local.FreerSimple qualified as LocalFreer
import Bench.Local.FusedEffects qualified as LocalFused
import Bench.Local.Handrolled qualified as LocalHandrolled
import Bench.Local.Heftia qualified as LocalHeftia
import Bench.Local.Mpeff.Safe qualified as LocalMpeffSafe
import Bench.Local.Mpeff.Unsafe qualified as LocalMpeff
import Bench.Local.Mtl qualified as LocalMtl
import Bench.Local.Polysemy qualified as LocalPolysemy
import Bench.Nondet.Eff qualified as NondetEff
import Bench.Nondet.Effective qualified as NondetEffective
import Bench.Nondet.EffectiveFullyStaged qualified as NondetEffectiveFullyStaged
import Bench.Nondet.EffectiveLightlyStaged qualified as NondetEffectiveLightlyStaged
import Bench.Nondet.EffectiveNaive qualified as NondetEffectiveNaive
import Bench.Nondet.FreerSimple qualified as NondetFreer
import Bench.Nondet.FusedEffects qualified as NondetFused
import Bench.Nondet.HandrolledListT qualified as NondetHandrolledListT
import Bench.Nondet.HandrolledLogicT qualified as NondetHandrolledLogicT
import Bench.Nondet.Heftia qualified as NondetHeftia
import Bench.Nondet.Mpeff.Safe qualified as NondetMpeffSafe
import Bench.Nondet.Mpeff.Unsafe qualified as NondetMpeff
import Bench.Nondet.MtlListT qualified as NondetListT
import Bench.Nondet.MtlLogict qualified as NondetLogict
import Bench.Nondet.Polysemy qualified as NondetPolysemy

#ifndef DISABLE_VERY_DEEP
import Bench.Catch.VeryDeep.Eff qualified as CatchVeryEff
import Bench.Catch.VeryDeep.Effectful qualified as CatchVeryEffectful
import Bench.Catch.VeryDeep.Effective qualified as CatchVeryEffective
import Bench.Catch.VeryDeep.EffectiveFullyStaged qualified as CatchVeryEffectiveFullyStaged
import Bench.Catch.VeryDeep.EffectiveLightlyStaged qualified as CatchVeryEffectiveLightlyStaged
import Bench.Catch.VeryDeep.EffectiveNaive qualified as CatchVeryEffectiveNaive
import Bench.Catch.VeryDeep.FreerSimple qualified as CatchVeryFreer
#ifndef BENCH_O2
import Bench.Catch.VeryDeep.FusedEffects qualified as CatchVeryFused
#endif
import Bench.Catch.VeryDeep.Handrolled qualified as CatchVeryHandrolled
import Bench.Catch.VeryDeep.Heftia qualified as CatchVeryHeftia
import Bench.Catch.VeryDeep.Mpeff.Safe qualified as CatchVeryMpeffSafe
import Bench.Catch.VeryDeep.Mpeff.Unsafe qualified as CatchVeryMpeff
import Bench.Catch.VeryDeep.Mtl qualified as CatchVeryMtl
import Bench.Catch.VeryDeep.Polysemy qualified as CatchVeryPolysemy
import Bench.Countdown.VeryDeep.Eff qualified as CountdownVeryEff
import Bench.Countdown.VeryDeep.Effectful qualified as CountdownVeryEffectful
import Bench.Countdown.VeryDeep.Effective qualified as CountdownVeryEffective
import Bench.Countdown.VeryDeep.EffectiveFullyStaged qualified as CountdownVeryEffectiveFullyStaged
import Bench.Countdown.VeryDeep.EffectiveLightlyStaged qualified as CountdownVeryEffectiveLightlyStaged
import Bench.Countdown.VeryDeep.EffectiveNaive qualified as CountdownVeryEffectiveNaive
import Bench.Countdown.VeryDeep.FreerSimple qualified as CountdownVeryFreer
#ifndef BENCH_O2
import Bench.Countdown.VeryDeep.FusedEffects qualified as CountdownVeryFused
#endif
import Bench.Countdown.VeryDeep.Handrolled qualified as CountdownVeryHandrolled
import Bench.Countdown.VeryDeep.Heftia qualified as CountdownVeryHeftia
import Bench.Countdown.VeryDeep.Mpeff.Safe qualified as CountdownVeryMpeffSafe
import Bench.Countdown.VeryDeep.Mpeff.Unsafe qualified as CountdownVeryMpeff
import Bench.Countdown.VeryDeep.Mtl qualified as CountdownVeryMtl
import Bench.Countdown.VeryDeep.Polysemy qualified as CountdownVeryPolysemy
import Bench.Local.VeryDeep.Eff qualified as LocalVeryEff
import Bench.Local.VeryDeep.Effectful qualified as LocalVeryEffectful
import Bench.Local.VeryDeep.Effective qualified as LocalVeryEffective
import Bench.Local.VeryDeep.EffectiveFullyStaged qualified as LocalVeryEffectiveFullyStaged
import Bench.Local.VeryDeep.EffectiveLightlyStaged qualified as LocalVeryEffectiveLightlyStaged
import Bench.Local.VeryDeep.EffectiveNaive qualified as LocalVeryEffectiveNaive
import Bench.Local.VeryDeep.FreerSimple qualified as LocalVeryFreer
#ifndef BENCH_O2
import Bench.Local.VeryDeep.FusedEffects qualified as LocalVeryFused
#endif
import Bench.Local.VeryDeep.Handrolled qualified as LocalVeryHandrolled
import Bench.Local.VeryDeep.Heftia qualified as LocalVeryHeftia
import Bench.Local.VeryDeep.Mpeff.Safe qualified as LocalVeryMpeffSafe
import Bench.Local.VeryDeep.Mpeff.Unsafe qualified as LocalVeryMpeff
import Bench.Local.VeryDeep.Mtl qualified as LocalVeryMtl
import Bench.Local.VeryDeep.Polysemy qualified as LocalVeryPolysemy
import Bench.Nondet.VeryDeep.Eff qualified as NondetVeryEff
import Bench.Nondet.VeryDeep.Effective qualified as NondetVeryEffective
import Bench.Nondet.VeryDeep.EffectiveFullyStaged qualified as NondetVeryEffectiveFullyStaged
import Bench.Nondet.VeryDeep.EffectiveLightlyStaged qualified as NondetVeryEffectiveLightlyStaged
import Bench.Nondet.VeryDeep.EffectiveNaive qualified as NondetVeryEffectiveNaive
import Bench.Nondet.VeryDeep.FreerSimple qualified as NondetVeryFreer
#ifndef BENCH_O2
import Bench.Nondet.VeryDeep.FusedEffects qualified as NondetVeryFused
#endif
import Bench.Nondet.VeryDeep.HandrolledListT qualified as NondetVeryHandrolledListT
import Bench.Nondet.VeryDeep.HandrolledLogicT qualified as NondetVeryHandrolledLogicT
import Bench.Nondet.VeryDeep.Heftia qualified as NondetVeryHeftia
import Bench.Nondet.VeryDeep.Mpeff.Safe qualified as NondetVeryMpeffSafe
import Bench.Nondet.VeryDeep.Mpeff.Unsafe qualified as NondetVeryMpeff
import Bench.Nondet.VeryDeep.MtlListT qualified as NondetVeryListT
import Bench.Nondet.VeryDeep.MtlLogict qualified as NondetVeryLogict
import Bench.Nondet.VeryDeep.Polysemy qualified as NondetVeryPolysemy
#endif
import Data.Functor ((<&>))
import Test.Tasty.Bench

main :: IO ()
main =
    defaultMain
        [ bgroup "countdown.shallow" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CountdownHeftia.countdown x
                    , bench "freer" $ nf CountdownFreer.countdown x
                    , bench "polysemy" $ nf CountdownPolysemy.countdown x
                    , bench "fused" $ nf CountdownFused.countdown x
                    , bench "effectful" $ nf CountdownEffectful.countdown x
                    , bench "eff" $ nf CountdownEff.countdown x
                    , bench "effective" $ nf CountdownEffective.countdown x
                    , bench "effective.fstg" $ nf CountdownEffectiveFullyStaged.countdown x
                    , bench "effective.naive" $ nf CountdownEffectiveNaive.countdown x
                    , bench "mp" $ nf CountdownMpeff.countdown x
                    , bench "mp.safe" $ nf CountdownMpeffSafe.countdown x
                    , bench "mtl.logict" $ nf CountdownMtl.countdown x
                    , bench "handrolled.logict" $ nf CountdownHandrolled.countdownShallow x
                    ]

        , bgroup "countdown.deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CountdownHeftia.countdownDeep x
                    , bench "freer" $ nf CountdownFreer.countdownDeep x
                    , bench "polysemy" $ nf CountdownPolysemy.countdownDeep x
                    , bench "fused" $ nf CountdownFused.countdownDeep x
                    , bench "effectful" $ nf CountdownEffectful.countdownDeep x
                    , bench "eff" $ nf CountdownEff.countdownDeep x
                    , bench "effective" $ nf CountdownEffective.countdownDeep x
                    , bench "effective.fstg" $ nf CountdownEffectiveFullyStaged.countdownDeep x
                    , bench "effective.lstg" $ nf CountdownEffectiveLightlyStaged.countdownDeep x
                    , bench "effective.naive" $ nf CountdownEffectiveNaive.countdownDeep x
                    , bench "mp" $ nf CountdownMpeff.countdownDeep x
                    , bench "mp.safe" $ nf CountdownMpeffSafe.countdownDeep x
                    , bench "mtl.logict" $ nf CountdownMtl.countdownDeep x
                    , bench "handrolled.logict" $ nf CountdownHandrolled.countdownDeep x
                    ]

#ifndef DISABLE_VERY_DEEP
        , bgroup "countdown.very-deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CountdownVeryHeftia.countdownDeep x
                    , bench "freer" $ nf CountdownVeryFreer.countdownDeep x
                    , bench "polysemy" $ nf CountdownVeryPolysemy.countdownDeep x
#ifndef BENCH_O2
                    , bench "fused" $ nf CountdownVeryFused.countdownDeep x
#endif
                    , bench "effectful" $ nf CountdownVeryEffectful.countdownDeep x
                    , bench "eff" $ nf CountdownVeryEff.countdownDeep x
                    , bench "effective" $ nf CountdownVeryEffective.countdownDeep x
                    , bench "effective.fstg" $ nf CountdownVeryEffectiveFullyStaged.countdownDeep x
                    , bench "effective.lstg" $ nf CountdownVeryEffectiveLightlyStaged.countdownDeep x
                    , bench "effective.naive" $ nf CountdownVeryEffectiveNaive.countdownDeep x
                    , bench "mp" $ nf CountdownVeryMpeff.countdownDeep x
                    , bench "mp.safe" $ nf CountdownVeryMpeffSafe.countdownDeep x
                    , bench "mtl.logict" $ nf CountdownVeryMtl.countdownDeep x
                    , bench "handrolled.logict" $ nf CountdownVeryHandrolled.countdownDeep x
                    ]
#endif

        , bgroup "catch.shallow" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CatchHeftia.catchBench x
                    , bench "freer" $ nf CatchFreer.catchBench x
                    , bench "polysemy" $ nf CatchPolysemy.catchBench x
                    , bench "fused" $ nf CatchFused.catchBench x
                    , bench "effectful" $ nf CatchEffectful.catchBench x
                    , bench "eff" $ nf CatchEff.catchBench x
                    , bench "mp" $ nf CatchMpeff.catchBench x
                    , bench "mp.safe" $ nf CatchMpeffSafe.catchBench x
                    , bench "mtl.logict" $ nf CatchMtl.catchBench x
                    , bench "effective" $ nf CatchEffective.catchBench x
                    , bench "effective.fstg" $ nf CatchEffectiveFullyStaged.catchBench x
                    , bench "effective.naive" $ nf CatchEffectiveNaive.catchBench x
                    , bench "handrolled.logict" $ nf CatchHandrolled.catchShallow x
                    ]

        , bgroup "catch.deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CatchHeftia.catchDeep x
                    , bench "freer" $ nf CatchFreer.catchDeep x
                    , bench "polysemy" $ nf CatchPolysemy.catchDeep x
                    , bench "fused" $ nf CatchFused.catchDeep x
                    , bench "effectful" $ nf CatchEffectful.catchDeep x
                    , bench "eff" $ nf CatchEff.catchDeep x
                    , bench "mp" $ nf CatchMpeff.catchDeep x
                    , bench "mp.safe" $ nf CatchMpeffSafe.catchDeep x
                    , bench "mtl.logict" $ nf CatchMtl.catchDeep x
                    , bench "effective" $ nf CatchEffective.catchDeep x
                    , bench "effective.fstg" $ nf CatchEffectiveFullyStaged.catchDeep x
                    , bench "effective.lstg" $ nf CatchEffectiveLightlyStaged.catchDeep x
                    , bench "effective.naive" $ nf CatchEffectiveNaive.catchDeep x
                    , bench "handrolled.logict" $ nf CatchHandrolled.catchDeep x
                    ]

#ifndef DISABLE_VERY_DEEP
        , bgroup "catch.very-deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf CatchVeryHeftia.catchDeep x
                    , bench "freer" $ nf CatchVeryFreer.catchDeep x
                    , bench "polysemy" $ nf CatchVeryPolysemy.catchDeep x
#ifndef BENCH_O2
                    , bench "fused" $ nf CatchVeryFused.catchDeep x
#endif
                    , bench "effectful" $ nf CatchVeryEffectful.catchDeep x
                    , bench "eff" $ nf CatchVeryEff.catchDeep x
                    , bench "mp" $ nf CatchVeryMpeff.catchDeep x
                    , bench "mp.safe" $ nf CatchVeryMpeffSafe.catchDeep x
                    , bench "mtl.logict" $ nf CatchVeryMtl.catchDeep x
                    , bench "effective" $ nf CatchVeryEffective.catchDeep x
                    , bench "effective.fstg" $ nf CatchVeryEffectiveFullyStaged.catchDeep x
                    , bench "effective.lstg" $ nf CatchVeryEffectiveLightlyStaged.catchDeep x
                    , bench "effective.naive" $ nf CatchVeryEffectiveNaive.catchDeep x
                    , bench "handrolled.logict" $ nf CatchVeryHandrolled.catchDeep x
                    ]
#endif

        , bgroup "local.shallow" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf LocalHeftia.localBench x
                    , bench "freer" $ nf LocalFreer.localBench x
                    , bench "polysemy" $ nf LocalPolysemy.localBench x
                    , bench "fused" $ nf LocalFused.localBench x
                    , bench "effectful" $ nf LocalEffectful.localBench x
                    , bench "eff" $ nf LocalEff.localBench x
                    , bench "effective" $ nf LocalEffective.localBench x
                    , bench "effective.fstg" $ nf LocalEffectiveFullyStaged.localBench x
                    , bench "effective.naive" $ nf LocalEffectiveNaive.localBench x
                    , bench "mp" $ nf LocalMpeff.localBench x
                    , bench "mp.safe" $ nf LocalMpeffSafe.localBench x
                    , bench "mtl.logict" $ nf LocalMtl.localBench x
                    , bench "handrolled.logict" $ nf LocalHandrolled.localShallow x
                    ]

        , bgroup "local.deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf LocalHeftia.localDeep x
                    , bench "freer" $ nf LocalFreer.localDeep x
                    , bench "polysemy" $ nf LocalPolysemy.localDeep x
                    , bench "fused" $ nf LocalFused.localDeep x
                    , bench "effectful" $ nf LocalEffectful.localDeep x
                    , bench "eff" $ nf LocalEff.localDeep x
                    , bench "effective" $ nf LocalEffective.localDeep x
                    , bench "effective.fstg" $ nf LocalEffectiveFullyStaged.localDeep x
                    , bench "effective.lstg" $ nf LocalEffectiveLightlyStaged.localDeep x
                    , bench "effective.naive" $ nf LocalEffectiveNaive.localDeep x
                    , bench "mp" $ nf LocalMpeff.localDeep x
                    , bench "mp.safe" $ nf LocalMpeffSafe.localDeep x
                    , bench "mtl.logict" $ nf LocalMtl.localDeep x
                    , bench "handrolled.logict" $ nf LocalHandrolled.localDeep x
                    ]

#ifndef DISABLE_VERY_DEEP
        , bgroup "local.very-deep" $
            [10000] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf LocalVeryHeftia.localDeep x
                    , bench "freer" $ nf LocalVeryFreer.localDeep x
                    , bench "polysemy" $ nf LocalVeryPolysemy.localDeep x
#ifndef BENCH_O2
                    , bench "fused" $ nf LocalVeryFused.localDeep x
#endif
                    , bench "effectful" $ nf LocalVeryEffectful.localDeep x
                    , bench "eff" $ nf LocalVeryEff.localDeep x
                    , bench "effective" $ nf LocalVeryEffective.localDeep x
                    , bench "effective.fstg" $ nf LocalVeryEffectiveFullyStaged.localDeep x
                    , bench "effective.lstg" $ nf LocalVeryEffectiveLightlyStaged.localDeep x
                    , bench "effective.naive" $ nf LocalVeryEffectiveNaive.localDeep x
                    , bench "mp" $ nf LocalVeryMpeff.localDeep x
                    , bench "mp.safe" $ nf LocalVeryMpeffSafe.localDeep x
                    , bench "mtl.logict" $ nf LocalVeryMtl.localDeep x
                    , bench "handrolled.logict" $ nf LocalVeryHandrolled.localDeep x
                    ]
#endif

        , bgroup "nondet.shallow" $
            [32] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf NondetHeftia.pyth x
                    , bench "freer" $ nf NondetFreer.pyth x
                    , bench "polysemy" $ nf NondetPolysemy.pyth x
                    , bench "fused" $ nf NondetFused.pyth x
                    , bench "eff" $ nf NondetEff.pyth x
                    , bench "effective" $ nf NondetEffective.pyth x
                    , bench "effective.fstg" $ nf NondetEffectiveFullyStaged.pyth x
                    , bench "effective.naive" $ nf NondetEffectiveNaive.pyth x
                    , bench "mp" $ nf NondetMpeff.pyth x
                    , bench "mp.safe" $ nf NondetMpeffSafe.pyth x
                    , bench "mtl.listt" $ nf NondetListT.pyth x
                    , bench "mtl.logict" $ nf NondetLogict.pyth x
                    , bench "handrolled.listt" $ nf NondetHandrolledListT.pyth x
                    , bench "handrolled.logict" $ nf NondetHandrolledLogicT.pyth x
                    ]

        , bgroup "nondet.deep" $
            [32] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf NondetHeftia.pythDeep x
                    , bench "freer" $ nf NondetFreer.pythDeep x
                    , bench "polysemy" $ nf NondetPolysemy.pythDeep x
                    , bench "fused" $ nf NondetFused.pythDeep x
                    , bench "eff" $ nf NondetEff.pythDeep x
                    , bench "effective" $ nf NondetEffective.pythDeep x
                    , bench "effective.fstg" $ nf NondetEffectiveFullyStaged.pythDeep x
                    , bench "effective.lstg" $ nf NondetEffectiveLightlyStaged.pythDeep x
                    , bench "effective.naive" $ nf NondetEffectiveNaive.pythDeep x
                    , bench "mp" $ nf NondetMpeff.pythDeep x
                    , bench "mp.safe" $ nf NondetMpeffSafe.pythDeep x
                    , bench "mtl.listt" $ nf NondetListT.pythDeep x
                    , bench "mtl.logict" $ nf NondetLogict.pythDeep x
                    , bench "handrolled.listt" $ nf NondetHandrolledListT.pythDeep x
                    , bench "handrolled.logict" $ nf NondetHandrolledLogicT.pythDeep x
                    ]

#ifndef DISABLE_VERY_DEEP
        , bgroup "nondet.very-deep" $
            [32] <&> \x ->
                bgroup
                    (show x)
                    [ bench "heftia" $ nf NondetVeryHeftia.pythDeep x
                    , bench "freer" $ nf NondetVeryFreer.pythDeep x
                    , bench "polysemy" $ nf NondetVeryPolysemy.pythDeep x
#ifndef BENCH_O2
                    , bench "fused" $ nf NondetVeryFused.pythDeep x
#endif
                    , bench "eff" $ nf NondetVeryEff.pythDeep x
                    , bench "effective" $ nf NondetVeryEffective.pythDeep x
                    , bench "effective.fstg" $ nf NondetVeryEffectiveFullyStaged.pythDeep x
                    , bench "effective.lstg" $ nf NondetVeryEffectiveLightlyStaged.pythDeep x
                    , bench "effective.naive" $ nf NondetVeryEffectiveNaive.pythDeep x
                    , bench "mp" $ nf NondetVeryMpeff.pythDeep x
                    , bench "mp.safe" $ nf NondetVeryMpeffSafe.pythDeep x
                    , bench "mtl.listt" $ nf NondetVeryListT.pythDeep x
                    , bench "mtl.logict" $ nf NondetVeryLogict.pythDeep x
                    , bench "handrolled.listt" $ nf NondetVeryHandrolledListT.pythDeep x
                    , bench "handrolled.logict" $ nf NondetVeryHandrolledLogicT.pythDeep x
                    ]
#endif
        ]
